Groupe : The Odd Seagulls

Membres :

	- Lamya Abaline - 300038880

	- Raïssa Mohamed Abdillahi - 8671145

	- Brian Laliberté - 300023551

	- Mouna Laouane - 300023986

	- Manal Abaline - 300038881


Lien du répertoire GitHub : https://github.com/Blali056/ProjetSEGApp 