package com.theoddseagulls.segapp;

import android.content.Intent;
import android.view.View;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity {

    EditText email;
    EditText password;
    String type;
    public DB_handler myDataBase;
    private RadioGroup radioGroup;
    private RadioButton user,supplier;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

    }


    // onClick du bouton S'INSCRIRE
    public void registerClick(View view) {
        // Ouvre l'activite de bienvenu après l'inscription
        Intent intent = new Intent(getApplicationContext(), WelcomeActivity.class);
        startActivityForResult (intent,0);
    }
}
