package com.theoddseagulls.segapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    private EditText toastMsg;
    private Button toastIt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);




        toastMsg = (EditText) findViewById(R.id.etToast);
        toastIt= (Button) findViewById(R.id.btnToastIt);


        toastIt.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), toastMsg.getText().toString(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }




}
