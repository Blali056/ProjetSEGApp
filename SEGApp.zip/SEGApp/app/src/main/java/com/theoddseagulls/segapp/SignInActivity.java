package com.theoddseagulls.segapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SignInActivity extends AppCompatActivity {

    private EditText email;
    private EditText password;
    private TextView info;
    private Button login;
    private Button register;
    private DB_handler mydatabase= new DB_handler(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
    }

    // onClick du bouton SE CONNECTER
    public void loginClick(View view) {


        email = (EditText) findViewById(R.id.email);
        password = (EditText) findViewById(R.id.password);
        User user = new User(email.getText().toString(), password.getText().toString());

        String pass = (mydatabase.findUser(user)).getPassword();
        String e = (mydatabase.findUser(user)).getEmail();
        if (password.equals(pass) && email.equals(e)) {
            Intent intent = new Intent(SignInActivity.this, WelcomeActivity.class);
            intent.putExtra("Username", user.getPassword());
            startActivity(intent);
        } else {
            Toast pass1 = Toast.makeText(SignInActivity.this, "You are not registred", Toast.LENGTH_SHORT);
            pass1.show();
        }
    }

}
