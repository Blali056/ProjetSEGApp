package com.theoddseagulls.segapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class config extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config_activity);
    }
}
