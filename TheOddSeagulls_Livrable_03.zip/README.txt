ProjetSEGApp

Groupe : The Odd Seagulls

Membres :
Lamya Abaline- 300038880
Raissa Mohamed Abdillahi - 8671145
Brian Laliberte - 300023551
Mouna Laouane - 300023986
Manal Abaline - 300038881

Version d'Android Studio utilisee : 3.1

https://github.com/Blali056/ProjetSEGApp